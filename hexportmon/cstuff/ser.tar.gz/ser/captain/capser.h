

int writeport(int fd, char *chars);
int readport(int fd, char *result);
int getbaud(int fd);

